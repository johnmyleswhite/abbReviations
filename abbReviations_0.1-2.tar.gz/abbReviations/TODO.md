* Don't use global variable for mapping.
