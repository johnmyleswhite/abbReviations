* Don't use global variable for mapping.
* Handle more types of names/abbreviations:
  * N.C. versus NC versus North Carolina
  * Use deterministic logic to infer type being used.
  * Use probabilistic logic to infer type being used.
