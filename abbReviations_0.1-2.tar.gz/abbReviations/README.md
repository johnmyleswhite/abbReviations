# Abbreviation Translation

    library('abbReviations')
    state_to_abbreviation('New Jersey')
    abbreviation_to_state('NJ')
